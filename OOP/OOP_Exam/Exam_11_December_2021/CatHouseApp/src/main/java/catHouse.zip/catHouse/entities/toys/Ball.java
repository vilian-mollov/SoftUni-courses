package catHouse.entities.toys;

public class Ball extends BaseToy{

    private static final int INITIAL_SOFTNESS = 1;
    private static final double INITIAL_PRICE = 10.00;


    public Ball() {
        super(INITIAL_SOFTNESS, INITIAL_PRICE);
    }
}
